﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TempElementsLib.Interfaces
{
    public interface IMove
    {
        public void Move(string pathName);
    }
}
